List of the files included in this package:
./mteval-v14.pl : version 13a of the evaluation script. The history section
describes the changes that were introduced for each new release.
./ref2.xml : sample reference file
./src2.xml : sample source file
./tst2.xml : sample test file


To display all possible command line options:
./mteval-v14.pl -h


